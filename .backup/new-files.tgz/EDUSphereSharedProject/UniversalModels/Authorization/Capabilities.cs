using System;
using System.Collections.Generic;
using System.Linq;

namespace EDUSphereSharedProject.UniversalModels.Authorization
{
    /// <summary>
    /// Everything a user can be permitted to do, as a fixed vocabulary.
    ///
    /// This exists because the app asked the wrong question in 111 places. Code like
    /// <c>UserRole == "Teacher"</c> asks *who someone is* when what it needs to know is *what they
    /// may do*. That coupling is why adding a role meant a deployment, and why a typo in a role
    /// string ("Chef/Cook" against "KitchenStaff") silently produced an empty page instead of an
    /// error.
    ///
    /// Capabilities are a closed set, defined here and only here. Roles are open — they live in the
    /// database and may be created at any time — and a role is nothing more than a named bundle of
    /// these codes. Adding a role therefore needs no deployment. Adding a *capability* still does,
    /// because some code has to consume it; that is unavoidable in any scheme and is the honest
    /// limit of this approach.
    ///
    /// Codes are lower-case, dot-separated, and read noun-first: "students.create", not
    /// "create.students". Grouping by noun keeps a role's capability list scannable, and lets the
    /// admin UI group by prefix without a lookup table.
    /// </summary>
    public static class Capabilities
    {
        // -----------------------------------------------------------------------------
        // Platform — Philtiara staff only. Never granted to a school.
        // -----------------------------------------------------------------------------

        public const string PlatformTenantsView = "platform.tenants.view";
        public const string PlatformTenantsManage = "platform.tenants.manage";
        public const string PlatformLicenceManage = "platform.licence.manage";

        // -----------------------------------------------------------------------------
        // People
        // -----------------------------------------------------------------------------

        public const string UsersView = "users.view";
        public const string UsersCreate = "users.create";

        /// <summary>Suspend, restore and reset passwords.</summary>
        public const string UsersManage = "users.manage";

        public const string StudentsView = "students.view";
        public const string StudentsCreate = "students.create";
        public const string StudentsManage = "students.manage";

        public const string TeachersView = "teachers.view";
        public const string TeachersManage = "teachers.manage";

        public const string StaffManage = "staff.manage";

        /// <summary>Attach students to parents, and create parent accounts for them.</summary>
        public const string ParentsLink = "parents.link";

        // -----------------------------------------------------------------------------
        // Academic structure
        // -----------------------------------------------------------------------------

        public const string AcademicStructureManage = "academics.structure.manage";
        public const string TermsManage = "academics.terms.manage";
        public const string ClassesManage = "classes.manage";
        public const string CoursesManage = "courses.manage";

        public const string TimetableView = "timetable.view";

        /// <summary>Generate, edit and publish timetables, and set subject policy.</summary>
        public const string TimetableManage = "timetable.manage";

        // -----------------------------------------------------------------------------
        // Teaching
        // -----------------------------------------------------------------------------

        public const string LessonsManage = "lessons.manage";
        public const string AssignmentsManage = "assignments.manage";
        public const string AssignmentsMark = "assignments.mark";
        public const string ExamsManage = "exams.manage";
        public const string ExamsMark = "exams.mark";
        public const string AttendanceRecord = "attendance.record";
        public const string LiveClassesHost = "liveclasses.host";

        public const string LibraryView = "library.view";
        public const string LibraryManage = "library.manage";

        // -----------------------------------------------------------------------------
        // Report cards
        // -----------------------------------------------------------------------------

        /// <summary>See one's own report cards, or one's children's.</summary>
        public const string ReportCardsViewOwn = "reportcards.view.own";

        /// <summary>See every student's report cards in the school.</summary>
        public const string ReportCardsViewSchool = "reportcards.view.school";

        /// <summary>
        /// Enter marks. Scoped to the holder's own subject-classes unless they also hold
        /// <see cref="ReportCardsEnterSchoolwide"/>.
        ///
        /// The pairing is deliberate. Scope is a query shape — "the classes this teacher teaches"
        /// needs a join, not a boolean — so it stays in code. What becomes data is only *whether*
        /// the narrowing applies, which is exactly the distinction
        /// ReportCardEntryOrchestrator already draws with its SchoolWideRoles list.
        /// </summary>
        public const string ReportCardsEnter = "reportcards.enter";

        public const string ReportCardsEnterSchoolwide = "reportcards.enter.schoolwide";

        /// <summary>Reach the review screen: overall comments, conduct, sign-off.</summary>
        public const string ReportCardsPrepare = "reportcards.prepare";

        /// <summary>
        /// Act at the dean's stage of the report card workflow.
        ///
        /// Separate from <see cref="ReportCardsPrepare"/>, which only opens the screen. A report
        /// card moves through three stages — marks, then the dean, then the principal — and the
        /// state machine admits exactly one of them at a time. Expressing the stages as capabilities
        /// rather than as the role names "Dean" and "Principal" is what lets a school call the post
        /// Head of Year and still have the workflow work.
        /// </summary>
        public const string ReportCardsSignOffDean = "reportcards.signoff.dean";

        /// <summary>Act at the principal's stage of the report card workflow.</summary>
        public const string ReportCardsSignOffPrincipal = "reportcards.signoff.principal";

        public const string ReportCardsPositionsRecalculate = "reportcards.positions.recalculate";

        // -----------------------------------------------------------------------------
        // Operations
        // -----------------------------------------------------------------------------

        public const string TransportManage = "transport.manage";
        public const string TransportDrive = "transport.drive";
        public const string TransportViewOwn = "transport.view.own";

        public const string DiningManage = "dining.manage";
        public const string DiningInventoryManage = "dining.inventory.manage";

        public const string HostelManage = "hostel.manage";
        public const string HostelMaintenanceManage = "hostel.maintenance.manage";

        public const string ClinicManage = "clinic.manage";
        public const string ClinicVisitsRecord = "clinic.visits.record";
        public const string ClinicInventoryManage = "clinic.inventory.manage";

        // -----------------------------------------------------------------------------
        // Finance
        // -----------------------------------------------------------------------------

        public const string FinanceManage = "finance.manage";
        public const string FinanceFeeStructureManage = "finance.feestructure.manage";
        public const string FinanceGatewaysManage = "finance.gateways.manage";
        public const string FinanceReportsView = "finance.reports.view";

        /// <summary>A parent seeing their own children's fees.</summary>
        public const string FinancePortalViewOwn = "finance.portal.view.own";

        // -----------------------------------------------------------------------------
        // Communication
        // -----------------------------------------------------------------------------

        public const string ChatUse = "chat.use";
        public const string ChatGroupsManage = "chat.groups.manage";
        public const string ChatAudit = "chat.audit";

        // -----------------------------------------------------------------------------
        // Student / parent portals
        // -----------------------------------------------------------------------------

        public const string PortalStudent = "portal.student";
        public const string PortalParent = "portal.parent";

        // -----------------------------------------------------------------------------
        // Catalogue
        // -----------------------------------------------------------------------------

        /// <summary>
        /// The full vocabulary with admin-facing names, so the role editor can render itself
        /// without a second source of truth to keep in step.
        /// </summary>
        public static readonly IReadOnlyList<CapabilityDefinition> All = new List<CapabilityDefinition>
        {
            new(PlatformTenantsView, "View all schools", "Platform", "See every school on Ignis and its licence state.", PlatformOnly: true),
            new(PlatformTenantsManage, "Register and edit schools", "Platform", "Add schools and change their details.", PlatformOnly: true),
            new(PlatformLicenceManage, "Manage licences", "Platform", "Activate, renew and terminate school licences.", PlatformOnly: true),

            new(UsersView, "View users", "People", "See the school's user accounts."),
            new(UsersCreate, "Add users", "People", "Create new accounts. Blocked when the licence is invalid."),
            new(UsersManage, "Manage accounts", "People", "Suspend, restore and reset passwords."),
            new(StudentsView, "View students", "People", "See the student roll."),
            new(StudentsCreate, "Enrol students", "People", "Add students individually or in bulk."),
            new(StudentsManage, "Edit students", "People", "Change student details and class placement."),
            new(TeachersView, "View teachers", "People", "See the teaching staff."),
            new(TeachersManage, "Manage teachers", "People", "Add teachers and assign them to classes."),
            new(StaffManage, "Manage staff", "People", "Add and edit non-teaching staff."),
            new(ParentsLink, "Link parents", "People", "Attach students to parents and create parent accounts."),

            new(AcademicStructureManage, "Manage academic structure", "Academics", "Levels, sections and streams."),
            new(TermsManage, "Manage terms", "Academics", "Term dates and report card windows."),
            new(ClassesManage, "Manage classes", "Academics", "Create classes and assign teachers."),
            new(CoursesManage, "Manage courses", "Academics", "Course and syllabus setup."),
            new(TimetableView, "View timetable", "Academics", "See published timetables."),
            new(TimetableManage, "Manage timetable", "Academics", "Generate, edit and publish timetables; set subject policy."),

            new(LessonsManage, "Manage lessons", "Teaching", "Create and publish lesson material."),
            new(AssignmentsManage, "Manage assignments", "Teaching", "Set and publish assignments."),
            new(AssignmentsMark, "Mark assignments", "Teaching", "Grade submitted assignments."),
            new(ExamsManage, "Manage exams", "Teaching", "Create exams, tests and quizzes."),
            new(ExamsMark, "Mark exams", "Teaching", "Grade exams, tests and quizzes."),
            new(AttendanceRecord, "Record attendance", "Teaching", "Take and amend class attendance."),
            new(LiveClassesHost, "Host live classes", "Teaching", "Create and run online classes."),
            new(LibraryView, "Use the library", "Teaching", "Browse and borrow library material."),
            new(LibraryManage, "Manage the library", "Teaching", "Add titles and manage lending."),

            new(ReportCardsViewOwn, "View own report cards", "Report cards", "A student's own, or a parent's children's."),
            new(ReportCardsViewSchool, "View all report cards", "Report cards", "Every student in the school."),
            new(ReportCardsEnter, "Enter marks", "Report cards", "Mark students in one's own subject-classes."),
            new(ReportCardsEnterSchoolwide, "Enter marks for any class", "Report cards", "Removes the own-classes restriction."),
            new(ReportCardsPrepare, "Prepare report cards", "Report cards", "Overall comments, conduct and sign-off."),
            new(ReportCardsSignOffDean, "Sign off as dean", "Report cards", "Act at the dean's stage of the report card workflow."),
            new(ReportCardsSignOffPrincipal, "Sign off as principal", "Report cards", "Act at the principal's stage of the report card workflow."),
            new(ReportCardsPositionsRecalculate, "Recalculate positions", "Report cards", "Renumber class and school positions."),

            new(TransportManage, "Manage transport", "Operations", "Fleet, routes, trips and bus staff."),
            new(TransportDrive, "Driver portal", "Operations", "Run assigned trips and record pickups."),
            new(TransportViewOwn, "Track own transport", "Operations", "A parent following their child's bus."),
            new(DiningManage, "Manage dining", "Operations", "Dining halls, menus and meal sessions."),
            new(DiningInventoryManage, "Manage kitchen inventory", "Operations", "Kitchen stock and supplies."),
            new(HostelManage, "Manage hostels", "Operations", "Hostels, rooms and allocations."),
            new(HostelMaintenanceManage, "Manage hostel maintenance", "Operations", "Room issues and repairs."),
            new(ClinicManage, "Manage clinics", "Operations", "Clinics and clinic staff."),
            new(ClinicVisitsRecord, "Record clinic visits", "Operations", "Log visits and medication given."),
            new(ClinicInventoryManage, "Manage medical inventory", "Operations", "Medication stock."),

            new(FinanceManage, "Manage finance", "Finance", "Invoices, payments and ledgers."),
            new(FinanceFeeStructureManage, "Manage fee structures", "Finance", "Fees, buckets and billing rules."),
            new(FinanceGatewaysManage, "Manage payment gateways", "Finance", "Payment provider configuration."),
            new(FinanceReportsView, "View finance reports", "Finance", "Financial dashboards and statements."),
            new(FinancePortalViewOwn, "View own fees", "Finance", "A parent seeing their children's fees."),

            new(ChatUse, "Use chat", "Communication", "Send and receive messages."),
            new(ChatGroupsManage, "Manage chat groups", "Communication", "Create and administer class and parent groups."),
            new(ChatAudit, "Audit chat", "Communication", "Review message history for safeguarding."),

            new(PortalStudent, "Student portal", "Portals", "The student's own dashboard and lessons."),
            new(PortalParent, "Parent portal", "Portals", "The parent's dashboard and children's progress."),
        };

        private static readonly HashSet<string> KnownCodes =
            new(All.Select(c => c.Code), StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// Whether a code is part of the vocabulary.
        ///
        /// Worth calling when loading role capabilities from the database: a code that no longer
        /// exists should be reported and ignored, not silently granted or silently dropped. The
        /// current failure mode — a role string nobody matches — is precisely what this prevents.
        /// </summary>
        public static bool IsKnown(string? code) =>
            !string.IsNullOrWhiteSpace(code) && KnownCodes.Contains(code);

        public static IEnumerable<IGrouping<string, CapabilityDefinition>> ByCategory() =>
            All.GroupBy(c => c.Category);
    }

    /// <param name="PlatformOnly">Philtiara staff only. The role editor must never offer these to a
    /// school, however its roles are configured.</param>
    public record CapabilityDefinition(
        string Code,
        string Name,
        string Category,
        string Description,
        bool PlatformOnly = false);
}
