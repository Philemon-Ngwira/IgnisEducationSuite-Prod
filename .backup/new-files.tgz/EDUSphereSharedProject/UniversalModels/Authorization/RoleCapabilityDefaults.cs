using System;
using System.Collections.Generic;
using System.Linq;

namespace EDUSphereSharedProject.UniversalModels.Authorization
{
    /// <summary>
    /// What each built-in role can do today.
    ///
    /// This is the migration bridge. Call sites move from <c>UserRole == "Teacher"</c> to
    /// <c>Can(Capabilities.ReportCardsEnter)</c> straight away, while the answer still comes from
    /// this table — so the refactor changes no behaviour and can proceed a screen at a time. Once
    /// the call sites are converted, the source of truth moves to the database and this becomes the
    /// seed for it. Nothing above has to change when that happens.
    ///
    /// It is therefore written to reproduce the app's *current* behaviour, not its ideal behaviour.
    /// Where today's grants look too broad, they are kept and flagged rather than quietly tightened:
    /// a refactor that also changes who can see what is a refactor nobody can review.
    /// </summary>
    public static class RoleCapabilityDefaults
    {
        /// <summary>Granted to every signed-in role. Chat is the only genuinely universal feature —
        /// every branch of the navigation carries a link to it.</summary>
        private static readonly string[] Everyone =
        {
            Capabilities.ChatUse,
        };

        private static readonly Dictionary<string, string[]> Map =
            new(StringComparer.OrdinalIgnoreCase)
            {
                // Philtiara staff. Deliberately holds no school-scoped capability at all: a
                // SuperAdmin belongs to no school, and the console is cross-tenant oversight.
                ["SuperAdmin"] = new[]
                {
                    Capabilities.PlatformTenantsView,
                    Capabilities.PlatformTenantsManage,
                    Capabilities.PlatformLicenceManage,
                },

                ["Admin"] = new[]
                {
                    Capabilities.UsersView, Capabilities.UsersCreate, Capabilities.UsersManage,
                    Capabilities.StudentsView, Capabilities.StudentsCreate, Capabilities.StudentsManage,
                    Capabilities.TeachersView, Capabilities.TeachersManage,
                    Capabilities.StaffManage, Capabilities.ParentsLink,

                    Capabilities.AcademicStructureManage, Capabilities.TermsManage,
                    Capabilities.ClassesManage, Capabilities.CoursesManage,
                    Capabilities.TimetableView, Capabilities.TimetableManage,

                    Capabilities.LibraryView, Capabilities.LibraryManage,

                    Capabilities.ReportCardsViewSchool,
                    Capabilities.ReportCardsEnter, Capabilities.ReportCardsEnterSchoolwide,
                    Capabilities.ReportCardsPrepare, Capabilities.ReportCardsPositionsRecalculate,

                    Capabilities.TransportManage,
                    Capabilities.DiningManage, Capabilities.DiningInventoryManage,
                    Capabilities.HostelManage, Capabilities.HostelMaintenanceManage,
                    Capabilities.ClinicManage, Capabilities.ClinicInventoryManage,

                    Capabilities.FinanceManage, Capabilities.FinanceFeeStructureManage,
                    Capabilities.FinanceGatewaysManage, Capabilities.FinanceReportsView,

                    Capabilities.ChatGroupsManage, Capabilities.ChatAudit,
                },

                ["Teacher"] = new[]
                {
                    Capabilities.LessonsManage,
                    Capabilities.AssignmentsManage, Capabilities.AssignmentsMark,
                    Capabilities.ExamsManage, Capabilities.ExamsMark,
                    Capabilities.AttendanceRecord, Capabilities.LiveClassesHost,
                    Capabilities.CoursesManage,
                    Capabilities.LibraryView,
                    Capabilities.TimetableView,

                    // Note the absence of ReportCardsEnterSchoolwide: a teacher marks only their own
                    // subject-classes, which is what ReportCardEntryOrchestrator already enforces.
                    Capabilities.ReportCardsEnter,

                    // Matches today's menu, which gives teachers the school-wide Report Cards page.
                    // Narrowing this to their own classes is a behaviour change, so it is left for a
                    // follow-up rather than smuggled into the refactor.
                    Capabilities.ReportCardsViewSchool,
                },

                ["Dean"] = new[]
                {
                    Capabilities.HostelMaintenanceManage,
                    Capabilities.ReportCardsPrepare,
                    Capabilities.ReportCardsSignOffDean,
                    Capabilities.ReportCardsViewSchool,
                },

                ["Principal"] = new[]
                {
                    Capabilities.ReportCardsPrepare,
                    Capabilities.ReportCardsSignOffPrincipal,
                    Capabilities.ReportCardsViewSchool,
                },

                ["Finance"] = new[]
                {
                    Capabilities.FinanceManage, Capabilities.FinanceFeeStructureManage,
                    Capabilities.FinanceGatewaysManage, Capabilities.FinanceReportsView,
                },

                ["Student"] = new[]
                {
                    Capabilities.PortalStudent,
                    Capabilities.ReportCardsViewOwn,
                    Capabilities.LibraryView,
                    Capabilities.TimetableView,
                },

                ["Parent"] = new[]
                {
                    Capabilities.PortalParent,
                    Capabilities.ReportCardsViewOwn,
                    Capabilities.FinancePortalViewOwn,
                    Capabilities.TransportViewOwn,
                },

                ["Clinic Staff"] = new[]
                {
                    Capabilities.ClinicVisitsRecord,
                    Capabilities.ClinicInventoryManage,
                },

                ["TransportStaff"] = new[]
                {
                    Capabilities.TransportDrive,
                },

                // Kitchen staff have neither a navigation branch nor a dashboard branch today — the
                // dashboard checks "Chef/Cook" while everything else in the solution says
                // "KitchenStaff", so the role is entirely non-functional and lands on a blank page.
                // These are the capabilities the role evidently should have had.
                ["KitchenStaff"] = new[]
                {
                    Capabilities.DiningManage,
                    Capabilities.DiningInventoryManage,
                },

                // The misspelling, mapped to the same set. Kept so that anything still holding the
                // old string behaves identically rather than falling through to nothing, and so the
                // fix does not depend on finding every last reference first.
                ["Chef/Cook"] = new[]
                {
                    Capabilities.DiningManage,
                    Capabilities.DiningInventoryManage,
                },

                // A generic staff account. Today it reaches the Teacher/Admin dashboard branch but
                // has no menu of its own, so it is given only what everyone gets.
                ["Staff"] = Array.Empty<string>(),
            };

        /// <summary>
        /// The capabilities a set of roles confers, as a union.
        ///
        /// A union rather than a winner: someone who is both a Teacher and a Dean should be able to
        /// do both jobs. That removes most of the need for AppState's hardcoded rolePriority list,
        /// which exists only because a single role string had to be chosen. Where precedence still
        /// matters — a teacher deliberately narrowing to their own classes — that is the active-role
        /// switcher's job, and it stays.
        /// </summary>
        public static HashSet<string> For(IEnumerable<string?> roleNames)
        {
            var granted = new HashSet<string>(Everyone, StringComparer.OrdinalIgnoreCase);

            foreach (var role in roleNames ?? Enumerable.Empty<string>())
            {
                if (string.IsNullOrWhiteSpace(role)) continue;

                if (Map.TryGetValue(role.Trim(), out var capabilities))
                {
                    granted.UnionWith(capabilities);
                }
            }

            return granted;
        }

        public static HashSet<string> For(string? roleName) => For(new[] { roleName });

        /// <summary>Role names this table knows about. Anything else confers only the common set —
        /// which is the correct outcome for a role created in the database before its capabilities
        /// have been configured.</summary>
        public static IReadOnlyCollection<string> KnownRoles => Map.Keys.ToList();
    }
}
