using System;
using System.Collections.Generic;
using System.Linq;

namespace EDUSphereSharedProject.UniversalModels.Authorization
{
    public enum MenuItemKind
    {
        /// <summary>An ordinary in-app link.</summary>
        Link = 0,

        /// <summary>A container. Renders only when at least one child is visible.</summary>
        Group = 1,

        /// <summary>The communication hub, which carries its own unread badge and so is rendered by
        /// a dedicated component rather than as a plain link.</summary>
        Chat = 2,

        /// <summary>Leaves the app. Opens in a new tab.</summary>
        External = 3,
    }

    /// <summary>
    /// One entry in the navigation, as data.
    ///
    /// The menu used to be a 311-line switch over role names holding 78 hardcoded links, which is
    /// why a new role arrived with no menu at all — KitchenStaff has neither a branch here nor one
    /// on the dashboard, and lands nowhere. Expressing the menu as a tree of capability-gated items
    /// means a role's menu composes itself from what that role may do.
    ///
    /// Lives in the shared project so the same shape can later be served from the database without
    /// the renderer changing.
    /// </summary>
    public class MenuItemDto
    {
        public string Id { get; set; } = "";

        public MenuItemKind Kind { get; set; } = MenuItemKind.Link;

        public string Label { get; set; } = "";

        /// <summary>Key into the icon catalogue, not an icon itself. A menu row cannot carry SVG —
        /// see MenuIcons for why this is a curated lookup rather than reflection.</summary>
        public string? Icon { get; set; }

        /// <summary>Ignored for groups.</summary>
        public string? Href { get; set; }

        /// <summary>
        /// Capability required to see this item.
        ///
        /// On a <see cref="MenuItemKind.Group"/> this is an additional gate on top of the usual rule
        /// that a group needs a visible child: it is what keeps "Teaching" hidden from an
        /// administrator who happens to hold one capability inside it. Most groups leave it unset
        /// and simply follow their children.
        /// </summary>
        public string? RequiredCapability { get; set; }

        /// <summary>Any one of these suffices. Used where a page serves more than one kind of user —
        /// Report Card Prep is reachable by whoever enters marks and by whoever signs them off.</summary>
        public string[]? RequiresAny { get; set; }

        public int SortOrder { get; set; }

        /// <summary>Forces a full page load. Needed by the few pages that re-read state on start-up.</summary>
        public bool ForceLoad { get; set; }

        /// <summary>Match the whole path rather than a prefix. Only the dashboard needs this.</summary>
        public bool MatchAll { get; set; }

        public List<MenuItemDto> Children { get; set; } = new();

        /// <summary>
        /// Whether this item should be shown to someone holding <paramref name="capabilities"/>.
        ///
        /// A group with no visible children is hidden even when its own gate passes — an empty
        /// expander is worse than no expander.
        /// </summary>
        public bool IsVisibleTo(IReadOnlySet<string> capabilities)
        {
            if (!string.IsNullOrWhiteSpace(RequiredCapability) && !capabilities.Contains(RequiredCapability))
                return false;

            if (RequiresAny is { Length: > 0 } && !RequiresAny.Any(capabilities.Contains))
                return false;

            if (Kind == MenuItemKind.Group)
                return Children.Any(child => child.IsVisibleTo(capabilities));

            return true;
        }

        /// <summary>Returns a copy containing only what this user may see, ordered. Returns null when
        /// nothing survives.</summary>
        public MenuItemDto? Prune(IReadOnlySet<string> capabilities)
        {
            if (!IsVisibleTo(capabilities)) return null;

            return new MenuItemDto
            {
                Id = Id,
                Kind = Kind,
                Label = Label,
                Icon = Icon,
                Href = Href,
                RequiredCapability = RequiredCapability,
                RequiresAny = RequiresAny,
                SortOrder = SortOrder,
                ForceLoad = ForceLoad,
                MatchAll = MatchAll,
                Children = Children
                    .Select(child => child.Prune(capabilities))
                    .Where(child => child is not null)
                    .Select(child => child!)
                    .OrderBy(child => child.SortOrder)
                    .ToList(),
            };
        }
    }
}
