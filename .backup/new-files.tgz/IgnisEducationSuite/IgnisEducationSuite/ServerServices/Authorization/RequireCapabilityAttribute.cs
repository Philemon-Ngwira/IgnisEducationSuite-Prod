using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace IgnisEducationSuite.ServerServices.Authorization
{
    /// <summary>
    /// Requires a capability to reach an endpoint.
    ///
    /// Use instead of <c>[Authorize(Roles = "...")]</c> on anything a new role might legitimately
    /// need. A role list in an attribute has the same problem as a role check in a page: adding a
    /// role means editing and redeploying every place that lists roles.
    ///
    /// Applied on top of authentication, not instead of it — keep [Authorize] on the controller.
    /// This answers "may you", not "who are you".
    ///
    /// <code>
    /// [HttpPost("school")]
    /// [RequireCapability(Capabilities.ReportCardsPositionsRecalculate)]
    /// public async Task&lt;IActionResult&gt; RecalculateSchool() { ... }
    /// </code>
    /// </summary>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
    public sealed class RequireCapabilityAttribute : Attribute, IAsyncAuthorizationFilter
    {
        private readonly string[] _capabilities;
        private readonly bool _requireAll;

        /// <param name="capabilities">
        /// Capabilities to check. With one, it must be held. With several, any one of them suffices
        /// unless <see cref="RequireAll"/> is set — "any" is the common case, because a screen is
        /// usually reachable by more than one kind of user.
        /// </param>
        public RequireCapabilityAttribute(params string[] capabilities)
        {
            _capabilities = capabilities ?? Array.Empty<string>();
        }

        /// <summary>Require every listed capability rather than any one of them.</summary>
        public bool RequireAll
        {
            get => _requireAll;
            init => _requireAll = value;
        }

        public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
        {
            // [AllowAnonymous] wins, as it does for [Authorize]. Without this, putting the attribute
            // on a controller would also close endpoints that must stay open — a payment gateway
            // posting a callback has no session to authorise.
            if (context.ActionDescriptor.EndpointMetadata.OfType<IAllowAnonymous>().Any())
                return;

            // An attribute with no capabilities is a programming mistake. Fail closed and say so,
            // rather than letting an empty list read as "no restriction".
            if (_capabilities.Length == 0)
            {
                context.Result = new ObjectResult("This endpoint is misconfigured.") { StatusCode = 500 };
                return;
            }

            var userId = context.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (string.IsNullOrWhiteSpace(userId))
            {
                context.Result = new UnauthorizedResult();
                return;
            }

            var resolver = context.HttpContext.RequestServices.GetRequiredService<CapabilityResolver>();
            var held = await resolver.GetAsync(userId);

            var allowed = _requireAll
                ? _capabilities.All(held.Contains)
                : _capabilities.Any(held.Contains);

            if (!allowed)
            {
                var logger = context.HttpContext.RequestServices
                    .GetRequiredService<ILoggerFactory>()
                    .CreateLogger<RequireCapabilityAttribute>();

                logger.LogWarning(
                    "{UserId} was refused {Path}: requires {Requirement} of [{Capabilities}]",
                    userId, context.HttpContext.Request.Path,
                    _requireAll ? "all" : "any", string.Join(", ", _capabilities));

                context.Result = new ForbidResult();
            }
        }
    }
}
