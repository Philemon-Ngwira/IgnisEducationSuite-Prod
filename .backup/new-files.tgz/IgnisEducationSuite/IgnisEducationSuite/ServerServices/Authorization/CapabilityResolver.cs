using System.Security.Claims;
using EduSphereDomain.Repositories;
using EDUSphereSharedProject.UniversalModels.Authorization;
using Microsoft.Extensions.Caching.Memory;

namespace IgnisEducationSuite.ServerServices.Authorization
{
    /// <summary>
    /// Works out what a user may do, server-side.
    ///
    /// This is the enforcement point. The browser is told the same answer so it can hide controls,
    /// but that copy is a convenience and cannot be trusted — it reaches the client, and anything
    /// that reaches the client can be edited there. Every guarded endpoint resolves capabilities
    /// again through this service.
    ///
    /// Roles come from the same initialisation data the rest of the app uses, rather than from the
    /// principal's role claims. That is deliberate: role claims do not survive the trip to
    /// WebAssembly, so resolving them the same way on both sides keeps one source of truth instead
    /// of two that can disagree.
    /// </summary>
    public class CapabilityResolver
    {
        /// <summary>
        /// Short, because it sits in front of a lookup that runs on guarded requests, and because a
        /// capability change must take effect while somebody is still signed in. Long enough that a
        /// burst of calls in one page load costs one lookup.
        /// </summary>
        private static readonly TimeSpan CacheDuration = TimeSpan.FromMinutes(2);

        private readonly EduSphereRepository _repository;
        private readonly IMemoryCache _cache;
        private readonly ILogger<CapabilityResolver> _logger;

        public CapabilityResolver(
            EduSphereRepository repository,
            IMemoryCache cache,
            ILogger<CapabilityResolver> logger)
        {
            _repository = repository;
            _cache = cache;
            _logger = logger;
        }

        private static string CacheKey(string userId) => $"capabilities::{userId}";

        /// <summary>
        /// Every capability this user holds, as a union across their roles.
        ///
        /// Returns an empty set rather than throwing when the user cannot be resolved. An empty set
        /// denies everything, which is the correct direction to fail on an authorisation question —
        /// the opposite of licensing, where failing open is correct because the answer restricts a
        /// paying customer rather than protecting data.
        /// </summary>
        public async Task<IReadOnlySet<string>> GetAsync(string? userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
                return new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            if (_cache.TryGetValue<IReadOnlySet<string>>(CacheKey(userId), out var cached) && cached is not null)
                return cached;

            var capabilities = await ResolveAsync(userId);
            _cache.Set(CacheKey(userId), capabilities, CacheDuration);

            return capabilities;
        }

        public async Task<bool> HasAsync(string? userId, string capability) =>
            (await GetAsync(userId)).Contains(capability);

        public Task<bool> HasAsync(ClaimsPrincipal user, string capability) =>
            HasAsync(user.FindFirstValue(ClaimTypes.NameIdentifier), capability);

        /// <summary>Drops a user's cached capabilities. Call after changing a role's capabilities or
        /// a user's roles, or the change will not be felt until the window expires.</summary>
        public void Invalidate(string userId) => _cache.Remove(CacheKey(userId));

        private async Task<IReadOnlySet<string>> ResolveAsync(string userId)
        {
            try
            {
                var data = (await _repository.GetInitializationDataResults(userId))?.FirstOrDefault();

                var roles = data?.RoleName?
                    .Split(',', StringSplitOptions.RemoveEmptyEntries)
                    .Select(r => r.Trim())
                    .ToList() ?? new List<string>();

                if (roles.Count == 0)
                {
                    _logger.LogWarning("No roles resolved for {UserId}; granting nothing", userId);
                    return new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                }

                return RoleCapabilityDefaults.For(roles);
            }
            catch (Exception ex)
            {
                // Deny on failure. An authorisation check that cannot complete must not be read as
                // permission.
                _logger.LogError(ex, "Could not resolve capabilities for {UserId}", userId);
                return new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            }
        }
    }
}
