using EDUSphereSharedProject.UniversalModels.Authorization;

namespace IgnisEducationSuite.Client.Services.Navigation
{
    /// <summary>
    /// The application menu, as one capability-gated tree.
    ///
    /// It replaces a switch that held a separate tree per role. That shape is why the same page
    /// appeared at different places for different people, why KitchenStaff has no menu at all, and
    /// why every new role needed a deployment. One tree, gated per item, composes each role's menu
    /// from what that role may do.
    ///
    /// Two consequences of collapsing to a single tree are worth stating, because they are visible
    /// changes rather than refactoring:
    ///
    ///  - A page now appears in one place for everyone. Library used to sit inside the Student and
    ///    Teacher portals and again under the administrator's Academics; it is now under Academics
    ///    for all three.
    ///  - Functional groups follow their children rather than being gated themselves, so a Dean —
    ///    who previously had two loose links — now sees Report Card Prep under Academics and
    ///    Maintenance under Operations. The portals are the exception: those carry their own gate,
    ///    which is what stops an administrator seeing a "Teaching" group because they happen to hold
    ///    one capability inside it.
    ///
    /// This is the same bridge pattern as RoleCapabilityDefaults: the tree lives in code today and
    /// moves to the database later. MenuService is the seam, so nothing that renders a menu changes
    /// when it does.
    /// </summary>
    public static class MenuCatalog
    {
        public static IReadOnlyList<MenuItemDto> Root => Build();

        private static List<MenuItemDto> Build() => new()
        {
            // ---------------------------------------------------------------- Platform
            Group("platform", "Platform", "platform", 10,
                gate: Capabilities.PlatformTenantsView,
                children: new()
                {
                    Link("platform.console", "Tenant Console", "platform", "TenantConsole", 10, Capabilities.PlatformTenantsView),
                    Link("platform.register", "Register School", "add-school", "ClientManagement", 20, Capabilities.PlatformTenantsManage),
                    Link("platform.admins", "School Administrators", "admin-panel", "ManageSchoolAdmins", 30, Capabilities.PlatformTenantsManage),
                }),

            // ---------------------------------------------------------------- People
            Group("people", "People", "supervisor", 20, children: new()
            {
                Link("people.users", "Users", "users", "UserManagement", 10, Capabilities.UsersView),
                Link("people.students", "Students", "student", "StudentManagement", 20, Capabilities.StudentsView),
                Link("people.teachers", "Teachers", "teacher", "TeacherManagement", 30, Capabilities.TeachersView),
            }),

            // ---------------------------------------------------------------- Academics
            Group("academics", "Academics", "school", 30, children: new()
            {
                Link("academics.terms", "Term Settings", "calendar-edit", "term-settings", 10, Capabilities.TermsManage, forceLoad: true),
                Link("academics.structure", "Academic Structure", "structure", "AcademicStructure", 20, Capabilities.AcademicStructureManage, forceLoad: true),
                Link("academics.classes", "Classes", "class", "ClassManagement", 30, Capabilities.ClassesManage),
                Link("academics.schedules", "Schedules", "timetable", "ClassSchedules", 40, Capabilities.TimetableManage),

                // Reachable by whoever enters marks and by whoever signs them off — the page itself
                // branches on which of those the viewer is.
                LinkAny("academics.reportcardprep", "Report Card Prep", "report-card", "ReportCardManagement", 50,
                    Capabilities.ReportCardsEnter, Capabilities.ReportCardsPrepare),

                Link("academics.reportcards", "Report Cards", "book", "ReportCards", 60, Capabilities.ReportCardsViewSchool),
                Link("academics.library", "Library", "library", "Library", 70, Capabilities.LibraryView),
            }),

            // ---------------------------------------------------------------- Teaching
            // Gated as a whole. Without this an administrator would see a "Teaching" group because
            // they hold Library and Report Cards, which sit here for teachers.
            Group("teaching", "Teaching", "teaching", 40,
                gateAny: new[]
                {
                    Capabilities.LessonsManage, Capabilities.ExamsManage,
                    Capabilities.AttendanceRecord, Capabilities.LiveClassesHost,
                },
                children: new()
                {
                    Link("teaching.live", "Live Classes", "live-class", "createliveclass", 10, Capabilities.LiveClassesHost),
                    Link("teaching.lessons", "Lessons", "lesson", "LessonManagement", 20, Capabilities.LessonsManage),
                    Link("teaching.assignments", "Assignments", "assignment", "AsssignmentManagement", 30, Capabilities.AssignmentsManage),
                    Link("teaching.marking", "Mark Assignments", "marking", "AssingmentChecking", 40, Capabilities.AssignmentsMark),
                    Link("teaching.exams", "Exams", "exam", "ExamQuizTestManagement", 50, Capabilities.ExamsManage),
                    Link("teaching.exammarking", "Mark Exams", "marking", "ExamMarking", 60, Capabilities.ExamsMark),
                    Link("teaching.attendance", "Attendance", "attendance", "StudentAttendance", 70, Capabilities.AttendanceRecord),
                    Link("teaching.courses", "Courses", "course", "CourseManagement", 80, Capabilities.CoursesManage),
                }),

            // ---------------------------------------------------------------- Operations
            Group("ops", "Operations", "operations", 50, children: new()
            {
                Group("ops.transport", "Transport", "bus", 10, children: new()
                {
                    Link("ops.transport.staff", "Bus Staff", "staff", "BusStaffManagement", 10, Capabilities.TransportManage),
                    Link("ops.transport.fleet", "Fleet & Registry", "bus-school", "fleet", 20, Capabilities.TransportManage),
                    Link("ops.transport.routes", "Route Planning", "route", "RoutePlanning", 30, Capabilities.TransportManage),
                    Link("ops.transport.trips", "Trip Schedule", "trip", "tripManagment", 40, Capabilities.TransportManage),

                    // The driver's own portal, and the administrator's view of it.
                    LinkAny("ops.transport.portal", "Driver Portal", "driver", "DriverPortal", 50,
                        Capabilities.TransportManage, Capabilities.TransportDrive),
                }),

                Group("ops.dining", "Dining", "dining", 20, children: new()
                {
                    Link("ops.dining.staff", "Kitchen Staff", "chef", "kitchen-staff", 10, Capabilities.DiningManage),
                    Link("ops.dining.inventory", "Kitchen Inventory", "inventory", "KitchenInventory", 20, Capabilities.DiningInventoryManage),
                    Link("ops.dining.hall", "Dining Hall", "dining-hall", "DiningManagement", 30, Capabilities.DiningManage),
                }),

                Group("ops.hostels", "Hostels", "hostel", 30, children: new()
                {
                    Link("ops.hostels.deans", "Deans & Wardens", "dean", "Deans", 10, Capabilities.HostelManage),
                    Link("ops.hostels.manage", "Hostels", "bedroom", "HostelManagement", 20, Capabilities.HostelManage),
                    Link("ops.hostels.maintenance", "Maintenance", "maintenance", "HostelRoomMaintainance", 30, Capabilities.HostelMaintenanceManage),
                }),

                Group("ops.clinic", "Clinic", "clinic", 40, children: new()
                {
                    Link("ops.clinic.staff", "Clinic Staff", "medical", "clinic-staff", 10, Capabilities.ClinicManage),
                    Link("ops.clinic.clinics", "Clinics", "hospital", "Clinics", 20, Capabilities.ClinicManage),
                    Link("ops.clinic.visits", "Clinic Visits", "doctor", "ClinicVisits", 30, Capabilities.ClinicVisitsRecord),
                    Link("ops.clinic.inventory", "Medical Inventory", "medication", "MedicalInventory", 40, Capabilities.ClinicInventoryManage),
                }),
            }),

            // ---------------------------------------------------------------- Finance
            Group("finance", "Finance", "bank-plus", 60, children: new()
            {
                Link("finance.management", "Finance Management", "finance", "finance-management", 10, Capabilities.FinanceManage),
                Link("finance.feestructure", "Fee Structure", "bank-plus", "feestructures", 20, Capabilities.FinanceFeeStructureManage),
                Link("finance.buckets", "Fee Accounts", "piggy-bank", "/finance/buckets", 30, Capabilities.FinanceFeeStructureManage),
                Link("finance.gateways", "Payment Gateways", "wallet", "/finance/payment-gateways", 40, Capabilities.FinanceGatewaysManage),

                // Staff view only. A parent reaches the same page through "Fees" in their own
                // portal — accepting FinancePortalViewOwn here as well put it in a parent's menu
                // twice, once under a Finance group holding nothing else.
                Link("finance.portal", "Finance Portal", "bank-circle", "FinancePortal", 50, Capabilities.FinanceManage),

                Link("finance.reports", "Finance Report", "chart-pie", "finance/dashboard", 60, Capabilities.FinanceReportsView),
            }),

            // ---------------------------------------------------------------- Student portal
            Group("portal.student", "Student Portal", "student", 70,
                gate: Capabilities.PortalStudent,
                children: new()
                {
                    Link("portal.student.lessons", "Lessons", "lesson", "StudentLessons", 10, Capabilities.PortalStudent),
                    Link("portal.student.assignments", "Assignments", "assignment", "StudentAssignments", 20, Capabilities.PortalStudent),
                    Link("portal.student.exams", "Exams", "exam", "Exams", 30, Capabilities.PortalStudent),
                    Link("portal.student.results", "Results", "report-card", "StudentResults", 40, Capabilities.PortalStudent),
                    Link("portal.student.reportcards", "Report Cards", "book", "ReportCards", 50, Capabilities.ReportCardsViewOwn),
                }),

            // ---------------------------------------------------------------- Parent portal
            Group("portal.parent", "Parent Portal", "account", 80,
                gate: Capabilities.PortalParent,
                children: new()
                {
                    Link("portal.parent.reportcards", "Report Cards", "book", "ReportCards", 10, Capabilities.ReportCardsViewOwn),
                    Link("portal.parent.transport", "Transport Portal", "bus-alert", "ParentTransportPortal", 20, Capabilities.TransportViewOwn),
                    Link("portal.parent.finance", "Fees", "bank-circle", "FinancePortal", 30, Capabilities.FinancePortalViewOwn),
                }),

            // ---------------------------------------------------------------- Everyone
            new MenuItemDto
            {
                Id = "chat",
                Kind = MenuItemKind.Chat,
                Label = "Ignis Communication Hub",
                Icon = "chat",
                SortOrder = 90,
                RequiredCapability = Capabilities.ChatUse,
            },

            Link("guide", "Guide", "info", "UserGuide", 100),
        };

        // -----------------------------------------------------------------------------
        // Builders — the tree above is read far more often than it is written, so the noise
        // of object initialisers is worth removing.
        // -----------------------------------------------------------------------------

        private static MenuItemDto Link(
            string id, string label, string icon, string href, int sortOrder,
            string? capability = null, bool forceLoad = false, bool matchAll = false) => new()
            {
                Id = id,
                Kind = MenuItemKind.Link,
                Label = label,
                Icon = icon,
                Href = href,
                SortOrder = sortOrder,
                RequiredCapability = capability,
                ForceLoad = forceLoad,
                MatchAll = matchAll,
            };

        private static MenuItemDto LinkAny(
            string id, string label, string icon, string href, int sortOrder,
            params string[] capabilities) => new()
            {
                Id = id,
                Kind = MenuItemKind.Link,
                Label = label,
                Icon = icon,
                Href = href,
                SortOrder = sortOrder,
                RequiresAny = capabilities,
            };

        private static MenuItemDto Group(
            string id, string label, string icon, int sortOrder,
            List<MenuItemDto> children, string? gate = null, string[]? gateAny = null) => new()
            {
                Id = id,
                Kind = MenuItemKind.Group,
                Label = label,
                Icon = icon,
                SortOrder = sortOrder,
                RequiredCapability = gate,
                RequiresAny = gateAny,
                Children = children,
            };
    }
}
