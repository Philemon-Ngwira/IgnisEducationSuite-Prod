using EDUSphereSharedProject.UniversalModels.Authorization;
using IgnisEducationSuite.Client.Pages.Finance;
using IgnisEducationSuite.Client.Pages.Management.SchoolOperations.TransportManagement.Driver;
using IgnisEducationSuite.Client.Pages.Management.SuperAdmin;
using IgnisEducationSuite.Client.Pages.Shared.DashboardLayers;
using IgnisEducationSuite.Client.Pages.Staff;

namespace IgnisEducationSuite.Client.Services.Navigation
{
    /// <summary>
    /// One panel on the dashboard, and who should see it.
    /// </summary>
    /// <param name="Component">
    /// Rendered with DynamicComponent. A type rather than a RenderFragment so the registry stays a
    /// plain list with no markup in it, and so a widget can be added without touching the dashboard.
    /// </param>
    public record DashboardWidget(
        string Id,
        Type Component,
        int SortOrder,
        string? RequiredCapability = null,
        string[]? RequiresAny = null)
    {
        public bool IsVisibleTo(IReadOnlySet<string> capabilities)
        {
            if (!string.IsNullOrWhiteSpace(RequiredCapability) && !capabilities.Contains(RequiredCapability))
                return false;

            if (RequiresAny is { Length: > 0 } && !RequiresAny.Any(capabilities.Contains))
                return false;

            return true;
        }
    }

    /// <summary>
    /// What appears on the dashboard, and for whom.
    ///
    /// The dashboard used to be a chain of <c>else if (AppState.UserRole == "...")</c>, which had
    /// three consequences. A role with no branch rendered a blank page — that is what SuperAdmin did
    /// until recently and what KitchenStaff still does, because its branch tests the string
    /// "Chef/Cook" while the rest of the solution says "KitchenStaff". A role could only ever see
    /// one panel, since the chain stops at the first match. And every new role needed a branch,
    /// which meant a deployment.
    ///
    /// A registry fixes all three: panels are selected by capability, a user sees every panel they
    /// qualify for, and a new role composes a dashboard from what it may do.
    ///
    /// Each widget is gated on the capability of the thing it shows, never on a role and never on a
    /// capability invented for the dashboard's own benefit — a UI-only permission would put the
    /// coupling straight back.
    /// </summary>
    public static class DashboardCatalog
    {
        public static IReadOnlyList<DashboardWidget> All { get; } = new List<DashboardWidget>
        {
            // Philtiara staff: cross-tenant overview.
            new("platform.overview", typeof(SuperAdminOverview), 10,
                RequiredCapability: Capabilities.PlatformTenantsView),

            // A school administrator's licence entitlement — seats used, expiry, what is allowed.
            new("school.licence", typeof(LicenseSummaryCard), 20,
                RequiredCapability: Capabilities.UsersCreate),

            // Students with no parent on record. Shows nothing when there are none.
            new("school.unparented", typeof(UnparentedStudentsCard), 30,
                RequiredCapability: Capabilities.ParentsLink),

            new("finance.report", typeof(FinanceReport), 40,
                RequiredCapability: Capabilities.FinanceReportsView),

            new("clinic.dashboard", typeof(ClinicDashboard), 50,
                RequiredCapability: Capabilities.ClinicVisitsRecord),

            new("transport.driver", typeof(DriverDashboard), 60,
                RequiredCapability: Capabilities.TransportDrive),

            // Reached previously only by a branch testing "Chef/Cook", a string nothing else in the
            // solution uses, so kitchen staff landed on an empty dashboard.
            new("dining.kitchen", typeof(Kitchen), 70,
                RequiredCapability: Capabilities.DiningInventoryManage),
        };

        public static List<DashboardWidget> For(IReadOnlySet<string> capabilities) =>
            All.Where(w => w.IsVisibleTo(capabilities))
               .OrderBy(w => w.SortOrder)
               .ToList();
    }
}
