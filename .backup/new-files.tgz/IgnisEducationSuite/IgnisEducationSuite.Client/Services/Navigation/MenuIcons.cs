using Bromix.MudBlazor.MaterialDesignIcons;
using MudBlazor;

namespace IgnisEducationSuite.Client.Services.Navigation
{
    /// <summary>
    /// Icon names the menu may use, resolved to the actual SVG.
    ///
    /// A curated dictionary rather than reflection over <c>Icons.Material.Filled</c>, for three
    /// reasons. It is bounded, so a bad or stale row in a menu table cannot reach into the icon
    /// library; it is trimming-safe, which reflection over a static class is not under WebAssembly's
    /// IL trimmer; and it spans two packages — MudBlazor's Material set and Bromix's Material Design
    /// set — which no single reflection target covers.
    ///
    /// An unknown name resolves to a neutral placeholder rather than throwing or rendering nothing,
    /// so a typo costs a wrong icon instead of a broken menu.
    /// </summary>
    public static class MenuIcons
    {
        public const string Fallback = "circle";

        private static readonly Dictionary<string, string> Catalogue =
            new(StringComparer.OrdinalIgnoreCase)
            {
                // ---- General ----
                ["circle"] = Icons.Material.Filled.Circle,
                ["dashboard"] = Icons.Material.Filled.Dashboard,
                ["info"] = Icons.Material.Filled.Info,
                ["pages"] = Icons.Material.Filled.Pages,
                ["chat"] = Icons.Material.Filled.ChatBubble,
                ["account"] = Icons.Material.Filled.AccountCircle,
                ["person"] = Icons.Material.Filled.Person,
                ["login"] = Icons.Material.Filled.Login,
                ["logout"] = Icons.Material.Filled.Logout,

                // ---- Platform ----
                ["platform"] = Icons.Material.Filled.Dns,
                ["add-school"] = Icons.Material.Filled.AddBusiness,
                ["admin-panel"] = Icons.Material.Filled.AdminPanelSettings,
                ["supervisor"] = Icons.Material.Filled.SupervisorAccount,
                ["verified"] = Icons.Material.Filled.VerifiedUser,

                // ---- People ----
                ["users"] = Icons.Material.Filled.SupervisedUserCircle,
                ["student"] = MaterialDesignIcons.Normal.HumanMaleFemaleChild,
                ["teacher"] = Icons.Material.Filled.Person,
                ["staff"] = MaterialDesignIcons.Normal.NaturePeople,

                // ---- Academics ----
                ["school"] = Icons.Material.Filled.School,
                ["calendar-edit"] = Icons.Material.Filled.EditCalendar,
                ["structure"] = Icons.Material.Filled.AccountTree,
                ["class"] = Icons.Material.Filled.Class,
                ["timetable"] = MaterialDesignIcons.Normal.Timetable,
                ["report-card"] = MaterialDesignIcons.Normal.CardAccountDetails,
                ["book"] = Icons.Material.Filled.Book,
                ["library"] = Icons.Material.Filled.LocalLibrary,
                ["library-books"] = Icons.Material.Filled.LibraryBooks,

                // ---- Teaching ----
                ["teaching"] = Icons.Material.Filled.Hub,
                ["live-class"] = Icons.Material.Filled.LiveTv,
                ["lesson"] = Icons.Material.Filled.School,
                ["assignment"] = Icons.Material.Filled.Work,
                ["marking"] = Icons.Material.Filled.Checklist,
                ["exam"] = MaterialDesignIcons.Normal.FileDocumentMultiple,
                ["attendance"] = Icons.Material.Filled.Mediation,
                ["course"] = Icons.Material.Filled.HomeWork,

                // ---- Operations ----
                ["operations"] = Icons.Material.Filled.Hotel,
                ["bus"] = MaterialDesignIcons.Normal.Bus,
                ["bus-school"] = MaterialDesignIcons.Normal.BusSchool,
                ["bus-alert"] = Icons.Material.Filled.BusAlert,
                ["route"] = MaterialDesignIcons.Normal.MapMarkerPath,
                ["trip"] = MaterialDesignIcons.Normal.Calendar,
                ["driver"] = MaterialDesignIcons.Normal.Steering,
                ["transport"] = Icons.Material.Filled.EmojiTransportation,
                ["dining"] = Icons.Material.Filled.DinnerDining,
                ["dining-hall"] = Icons.Material.Filled.Dining,
                ["chef"] = MaterialDesignIcons.Normal.ChefHat,
                ["inventory"] = MaterialDesignIcons.Normal.StorageTank,
                ["hostel"] = Icons.Material.Filled.Warehouse,
                ["bedroom"] = Icons.Material.Filled.BedroomChild,
                ["maintenance"] = Icons.Material.Filled.Build,
                ["dean"] = Icons.Material.Filled.Man,
                ["clinic"] = Icons.Material.Filled.LocalHospital,
                ["hospital"] = MaterialDesignIcons.Normal.Hospital,
                ["doctor"] = MaterialDesignIcons.Normal.Doctor,
                ["medical"] = Icons.Material.Filled.MedicalServices,
                ["medication"] = Icons.Material.Filled.Medication,

                // ---- Finance ----
                ["finance"] = MaterialDesignIcons.Normal.Finance,
                ["bank-plus"] = MaterialDesignIcons.Normal.BankPlus,
                ["bank-circle"] = MaterialDesignIcons.Normal.BankCircle,
                ["piggy-bank"] = MaterialDesignIcons.Normal.PiggyBank,
                ["wallet"] = Icons.Material.Filled.AccountBalanceWallet,
                ["chart-pie"] = MaterialDesignIcons.Normal.ChartPie,
            };

        /// <summary>The SVG for a name, or a neutral placeholder when the name is unknown.</summary>
        public static string Resolve(string? name)
        {
            if (!string.IsNullOrWhiteSpace(name) && Catalogue.TryGetValue(name, out var icon))
                return icon;

            return Catalogue[Fallback];
        }

        public static bool IsKnown(string? name) =>
            !string.IsNullOrWhiteSpace(name) && Catalogue.ContainsKey(name);

        /// <summary>Every usable name, for the future menu editor's icon picker.</summary>
        public static IReadOnlyCollection<string> Names => Catalogue.Keys.OrderBy(k => k).ToList();
    }
}
