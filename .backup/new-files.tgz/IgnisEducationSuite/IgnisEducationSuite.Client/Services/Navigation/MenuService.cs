using EDUSphereSharedProject.UniversalModels.Authorization;

namespace IgnisEducationSuite.Client.Services.Navigation
{
    public interface IMenuService
    {
        /// <summary>The menu this user should see, already pruned and ordered.</summary>
        Task<List<MenuItemDto>> GetMenuAsync();
    }

    /// <summary>
    /// Builds the navigation for the signed-in user.
    ///
    /// This is the seam. Today the tree comes from MenuCatalog and is filtered in the browser
    /// against AppState's capabilities; later it comes from the database over an API. The method is
    /// asynchronous now precisely so that move changes nothing in NavMenu — turning a synchronous
    /// call asynchronous afterwards would touch every caller.
    ///
    /// Filtering here is a display concern. It decides what is offered, not what is reachable:
    /// every page and endpoint behind these links is guarded independently, because a link that is
    /// merely absent can still be typed into the address bar.
    /// </summary>
    public class MenuService : IMenuService
    {
        private readonly AppState _appState;

        public MenuService(AppState appState)
        {
            _appState = appState;
        }

        public Task<List<MenuItemDto>> GetMenuAsync()
        {
            var capabilities = _appState.Capabilities;

            var menu = MenuCatalog.Root
                .Select(item => item.Prune(capabilities))
                .Where(item => item is not null)
                .Select(item => item!)
                .OrderBy(item => item.SortOrder)
                .ToList();

            return Task.FromResult(menu);
        }
    }
}
